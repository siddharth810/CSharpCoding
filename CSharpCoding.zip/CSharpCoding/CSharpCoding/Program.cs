﻿using CSharpCoding.DSA.Strings;
using System;
using System.IO;

class Program
{
    static void Main(string[] args)
    {
        string inputFilePath = "C:\\Users\\Siddharth\\source\\repos\\CSharpCoding\\Input.txt";
        string outputFilePath = "C:\\Users\\Siddharth\\source\\repos\\CSharpCoding\\Output.txt";

        // Read input from input.txt
        string inputText = File.ReadAllText(inputFilePath);

        // Process input (for demonstration, just echoing the input)
        string outputText = SwapStrings.Swap("Siddharth", "Satpute");

        // Write output to output.txt
        File.WriteAllText(outputFilePath, outputText);

        Console.WriteLine("Output written to output.txt.");
    }
}
