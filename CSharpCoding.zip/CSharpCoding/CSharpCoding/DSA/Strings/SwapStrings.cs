﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpCoding.DSA.Strings
{
    public static class SwapStrings
    {
        public static string Swap(string s1, string s2)
        { 
            s1 = s1+s2;
            s2 = s1.Substring(0, s1.Length - s2.Length);
            s1 = s1.Substring(s2.Length);
            return string.Format("After Swapping strings - s1 : {0} and s2 : {1}", s1, s2);    
        }
    }
}
